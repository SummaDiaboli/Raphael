import 'package:flutter/material.dart';
import 'mainApp.dart';

void main() => runApp(
      MainApp(),
    );
