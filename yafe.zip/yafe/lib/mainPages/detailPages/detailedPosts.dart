import 'package:flutter/material.dart';

class DetailedPosts extends StatefulWidget {
  @override
  _DetailedPostsState createState() => _DetailedPostsState();
}

class _DetailedPostsState extends State<DetailedPosts> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.blue,
    );
  }
}
