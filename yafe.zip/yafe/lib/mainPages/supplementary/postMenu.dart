/* import 'package:flutter/material.dart';

class CustomPopupMenu {
  CustomPopupMenu({this.title});

  String title;
}

List<CustomPopupMenu> choices = <CustomPopupMenu>[
  CustomPopupMenu(title: 'Settings')
];
 */